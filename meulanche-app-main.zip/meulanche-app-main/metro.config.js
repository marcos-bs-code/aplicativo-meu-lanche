module.exports = {
    resolver: {
      hermesParser: {
        enabled: false,
      },
    },
  };