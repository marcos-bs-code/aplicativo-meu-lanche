export interface TopBarProps {
    pageTitle?: string
}