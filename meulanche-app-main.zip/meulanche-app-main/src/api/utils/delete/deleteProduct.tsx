// import { app } from '../../config/firebaseConfig';

// import { getFirestore, collection, doc, deleteDoc } from '@firebase/firestore';


// //Método que exclui um documento na coleção do firebase
// // export async function deleteProduto(produtoId: string) {
// //     const db = getFirestore(app);
// //     const produtosRef = collection(db, "produtos");
// //     const produtoDocRef = doc(produtosRef, produtoId);
// //     try {
// //         await deleteDoc(produtoDocRef);
// //         console.log("Produto excluído com sucesso!");
// //     } catch (error) {
// //         console.log("Erro ao excluir o produto:", error);
// //     }
// // }